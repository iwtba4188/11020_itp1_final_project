#include "global.h"

void character_init();
void charater_process(ALLEGRO_EVENT event);
void charater_update();
void character_draw();
void character_destory();
