# I2P1_Final_project
Introduction to programming 1 final project
## Rules
- You can only use C language to do this project, otherwise you will get 0 point.
  Any C++ header file is not allow.
- Plagiarism is strictly not allowed

## Resource

- Allegro download: [https ://github.com/liballeg/allegro5/releases](https://github.com/liballeg/allegro5/releases)

- Allegro install(mac): https://hackmd.io/@kerwintsai/SkRTk6kCS
- Allegro install(Windows):  https://github.com/yuan7122/I2P1_Final_project/blob/master/tutorial/Allegro_install.pdf
- Allegro documentation: https://liballeg.org/a5docs/trunk/
- For more information refer to [tutorial folder](https://github.com/yuan7122/I2P1_Final_project/tree/master/tutorial)