#include "GameWindow.h"

int main(){
    Game_establish();
}
